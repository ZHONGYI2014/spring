create trigger delete_customer
  before DELETE
  on customer
  for each row
  INSERT INTO customer_delete(
	id,
	crm_user_id,
	phone,
	NAME,
	site_id,
	shop_code,
	sex,
	source,
	dd_source,
	backup_phone,
	identification_number,
	qq,
	wechat,
	province,
	city,
	birthday,
	remark,
	operator,
	belong_sales,
	seller_lable,
	LEVEL,
    create_type,
	creator,
	date_create,
	date_update
)SELECT
	id,
	crm_user_id,
	phone,
	NAME,
	site_id,
	shop_code,
	sex,
	source,
	dd_source,
	backup_phone,
	identification_number,
	qq,
	wechat,
	province,
	city,
	birthday,
	remark,
	operator,
	belong_sales,
	seller_lable,
	LEVEL,
    create_type,
	creator,
	date_create,
	date_update
FROM
	customer
WHERE
	customer.id = old.id
;

